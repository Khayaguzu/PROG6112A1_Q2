/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poepart1;

import javax.swing.JOptionPane;

/**
 *
 * @author RC_Student_lab
 */
public class Login1 {
    public static Login objUser = new Login();
    public static String userName;
    public static String password;
    public static String firstName;
    public static String lastName;
    public static void main(String[] args) {
        while (true) {
            String displayLoginStatus = returnLoginStatus();
            JOptionPane.showMessageDialog(null, displayLoginStatus);
        }
    }
    public static String returnLoginStatus() {
        String enteredUsername = JOptionPane.showInputDialog("Enter your username to login:");
        String enteredPassword = JOptionPane.showInputDialog("Enter your password to login:");
        boolean isLoggedIn = objUser.loginUser(enteredUsername, enteredPassword);
        String loginStatusMessage = objUser.returnLoginStatus(isLoggedIn);
        JOptionPane.showMessageDialog(null, loginStatusMessage);
        String statusSuccessful = "A successful login";
        String statusFail = "A failed login";
        boolean usernameTrue = objUser.checkUserName();
        boolean pwdTrue = objUser.checkpassword();
        if (usernameTrue && pwdTrue) {
            return statusSuccessful;
        } else {
            return statusFail;
        }
    }
}